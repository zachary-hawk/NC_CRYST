# NC_CRYST
Crystal Visualisation for CASTEP calculations including non-collinear magnetism.


## SIMPLE VISUALISATION
For the most basic visualisation, all you need is a CASTEP <seed>.cell file.
```
nc_cryst seed
```

## VOLUMETRIC
Three types of 3D data files are accepted, .den_fmt, .pot_fmt and .xsf. 
